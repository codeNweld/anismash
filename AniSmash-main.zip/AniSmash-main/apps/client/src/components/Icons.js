import HIDIVE from '../assets/icons/hidive.png'
import Bilibili from '../assets/icons/bilibili.png'
import Crunchyroll from '../assets/icons/crunchyroll.png'
import Youtube from '../assets/icons/youtube.png'
import Netflix from '../assets/icons/netflix.png'
import Disney from '../assets/icons/disneyplus.png'
import Hulu from '../assets/icons/hulu.png'
import Funimation from '../assets/icons/funimation.png'
import IQ from '../assets/icons/iq.png'
import Tubi from '../assets/icons/tubi.png'
import WeTV from '../assets/icons/wetv.png'

export const siteIcons = {
    'HIDIVE' : HIDIVE,
    'Bilibili TV': Bilibili,
    'Crunchyroll' : Crunchyroll,
    'YouTube' : Youtube,
    'Netflix' : Netflix,
    'Disney Plus' : Disney,
    'Hulu' : Hulu,
    'Funimation' : Funimation,
    'iQ' : IQ,
    'Tubi TV' : Tubi,
    'WeTV' : WeTV
}